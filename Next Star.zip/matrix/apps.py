from django.apps import AppConfig


class MatrixConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'matrix'
