from django.contrib import admin

from core.models import UserWallet
admin.site.register(UserWallet)